import axios from 'axios'

const api = axios.create({
  baseURL: 'https://localhost:5001/api',
  timeout: 60000,
})

function form(files, extra = {}) {
  const fd = new FormData()
  if (Array.isArray(files)) {
    files.forEach(f => fd.append('files', f))
  } else if (files) {
    fd.append('file', files)
  }
  Object.entries(extra).forEach(([k, v]) => fd.append(k, v))
  return fd
}

const opts = { responseType: 'blob' }

export const pdfApi = {
  merge:      (files)          => api.post('/pdf/merge',        form(files),          opts),
  compress:   (file, quality)  => api.post('/pdf/compress',     form(file, {quality}), opts),
  imageToPdf: (files)          => api.post('/pdf/image-to-pdf', form(files),          opts),
  pdfToImage: (file, format)   => api.post('/pdf/pdf-to-image', form(file, {format}), opts),
}

export const imageApi = {
  compress: (file, quality)              => api.post('/image/compress', form(file, {quality}), opts),
  convert:  (file, format)               => api.post('/image/convert',  form(file, {format}),  opts),
  resize:   (file, width, height, unit)  => api.post('/image/resize',   form(file, {width, height, unit}), opts),
}
