import { useState } from 'react'

export function useToolState() {
  const [files, setFiles] = useState([])
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState(null)
  const [error, setError] = useState(null)

  const removeFile = (index) => {
    setFiles(prev => prev.filter((_, i) => i !== index))
  }

  const reset = () => {
    setFiles([])
    setResult(null)
    setError(null)
  }

  const run = async (apiFn) => {
    setLoading(true)
    setError(null)
    setResult(null)
    try {
      const res = await apiFn()
      setResult(res)
    } catch (e) {
      setError(e?.response?.data?.message || e.message || 'Something went wrong.')
    } finally {
      setLoading(false)
    }
  }

  return { files, setFiles, loading, result, error, removeFile, reset, run }
}
